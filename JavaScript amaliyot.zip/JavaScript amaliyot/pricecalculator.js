var meva = 'olma';

meva == 'olma' && console.log('10 000');

var meva = 'nok'

meva == 'nok' && console.log('12 000');

var meva = 'tarvuz'

meva == 'tarvuz' && console.log('20 000');

 meva !== 'olma' && 'nok' &&  'tarvuz' && console.log('Bizda unday meva yoq');