var ball = prompt(100);

ball >= 85 && console.log("A");

ball >= 60 && console.log('B');

ball >= 49 && console.log('C')

ball = 48 && console.log('Failed')