let num = prompt("enter a number ")



let result = (num%2==0)? "juft": "toq";

console.log("The result is "+result);



